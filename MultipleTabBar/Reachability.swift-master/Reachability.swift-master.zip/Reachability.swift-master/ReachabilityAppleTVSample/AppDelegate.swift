//
//  AppDelegate.swift
//  ReachabilityAppleTVSample
//
//  Created by Stefan Schmitt on 10/12/15.
//  Copyright © 2015 Ashley Mills. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        return true
    }
}
